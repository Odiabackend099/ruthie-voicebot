# Copy this file and replace with your agent prompt. #
If you do not, the default prompt will be:

You are a helpful AI assistant. Please provide concise and accurate responses.