"""
Function Definitions for Deepgram Agent API
Defines sequential collector functions for conversational parameter collection.

Each action flow uses intermediate "collector" functions to enforce
one-at-a-time parameter collection instead of asking all questions at once.
"""

# =============================================================================
# BOOKING APPOINTMENT FLOW (6 parameters)
# Sequence: initiate -> name -> email -> date -> time -> service -> purpose -> confirm
# =============================================================================

BOOKING_FUNCTIONS = [
    {
        "name": "initiate_booking",
        "description": "Call this FIRST when user wants to book an appointment. This starts the booking flow and tells you to ask for their name.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_client_name",
        "description": "Call this AFTER user provides their name. Stores the name and tells you to ask for email next.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_name": {
                    "type": "string",
                    "description": "The customer's full name as they provided it"
                }
            },
            "required": ["client_name"]
        }
    },
    {
        "name": "collect_client_email",
        "description": "Call this AFTER user provides their email address. Stores the email and tells you to ask for phone number next.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_email": {
                    "type": "string",
                    "description": "Email address in format user@domain.com"
                }
            },
            "required": ["client_email"]
        }
    },
    {
        "name": "collect_client_phone",
        "description": "Call this AFTER user provides their phone number. Stores the phone and tells you to ask for company name next.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_phone": {
                    "type": "string",
                    "description": "Phone number with country code in E.164 format (e.g., +2348141995397)"
                }
            },
            "required": ["client_phone"]
        }
    },
    {
        "name": "collect_company_name",
        "description": "Call this AFTER user provides their company name. Stores the company name and tells you to ask for date next.",
        "parameters": {
            "type": "object",
            "properties": {
                "company_name": {
                    "type": "string",
                    "description": "The name of the customer's company or organization"
                }
            },
            "required": ["company_name"]
        }
    },
    {
        "name": "collect_booking_date",
        "description": "Call this AFTER user provides the appointment date. Stores the date and tells you to ask for time next.",
        "parameters": {
            "type": "object",
            "properties": {
                "booking_date": {
                    "type": "string",
                    "description": "Date in YYYY-MM-DD format (e.g., 2024-12-15). Convert natural language dates like 'next Tuesday' to this format."
                }
            },
            "required": ["booking_date"]
        }
    },
    {
        "name": "collect_booking_time",
        "description": "Call this AFTER user provides the appointment time. Stores the time and tells you to ask for service type next.",
        "parameters": {
            "type": "object",
            "properties": {
                "booking_time": {
                    "type": "string",
                    "description": "Time in HH:MM format (24-hour, e.g., 14:30 for 2:30 PM)"
                }
            },
            "required": ["booking_time"]
        }
    },
    {
        "name": "collect_service_type",
        "description": "Call this AFTER user provides the type of service. Stores the service type and tells you to ask for purpose next.",
        "parameters": {
            "type": "object",
            "properties": {
                "service_type": {
                    "type": "string",
                    "description": "Type of service (e.g., consultation, demo, follow-up, support)"
                }
            },
            "required": ["service_type"]
        }
    },
    {
        "name": "collect_purpose",
        "description": "Call this AFTER user describes the purpose of the appointment. Stores the purpose and tells you to confirm all details.",
        "parameters": {
            "type": "object",
            "properties": {
                "purpose": {
                    "type": "string",
                    "description": "Brief description of the appointment's purpose"
                }
            },
            "required": ["purpose"]
        }
    },
    {
        "name": "confirm_and_book",
        "description": "Call this ONLY after user confirms all details are correct. This actually creates the booking. NEVER call this until you've confirmed with the user.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_name": {"type": "string"},
                "client_email": {"type": "string"},
                "client_phone": {"type": "string"},
                "company_name": {"type": "string"},
                "booking_date": {"type": "string"},
                "booking_time": {"type": "string"},
                "service_type": {"type": "string"},
                "purpose": {"type": "string"}
            },
            "required": ["client_name", "client_email", "client_phone", "company_name", "booking_date", "booking_time", "service_type", "purpose"]
        }
    },
]

# =============================================================================
# RESCHEDULE APPOINTMENT FLOW (3 parameters)
# Sequence: initiate -> client_email -> new_date -> new_time -> confirm
# =============================================================================

RESCHEDULE_FUNCTIONS = [
    {
        "name": "initiate_reschedule",
        "description": "Call this FIRST when user wants to reschedule an appointment. Asks for their email address.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_reschedule_email",
        "description": "Call this AFTER user provides their email address. Use this to look up their booking.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_email": {
                    "type": "string",
                    "description": "The email address associated with the booking"
                }
            },
            "required": ["client_email"]
        }
    },
    {
        "name": "collect_new_date",
        "description": "Call this AFTER user provides the new preferred date.",
        "parameters": {
            "type": "object",
            "properties": {
                "new_date": {
                    "type": "string",
                    "description": "New date in YYYY-MM-DD format"
                }
            },
            "required": ["new_date"]
        }
    },
    {
        "name": "collect_new_time",
        "description": "Call this AFTER user provides the new preferred time.",
        "parameters": {
            "type": "object",
            "properties": {
                "new_time": {
                    "type": "string",
                    "description": "New time in HH:MM format (24-hour)"
                }
            },
            "required": ["new_time"]
        }
    },
    {
        "name": "confirm_and_reschedule",
        "description": "Call this ONLY after user confirms the new date and time. Actually reschedules the appointment.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_email": {"type": "string"},
                "new_date": {"type": "string"},
                "new_time": {"type": "string"}
            },
            "required": ["client_email", "new_date", "new_time"]
        }
    },
]

# =============================================================================
# CANCEL APPOINTMENT FLOW (1 parameter)
# Sequence: initiate -> email -> confirm
# =============================================================================

CANCEL_FUNCTIONS = [
    {
        "name": "initiate_cancel",
        "description": "Call this FIRST when user wants to cancel an appointment. Asks for their email address.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_cancel_email",
        "description": "Call this AFTER user provides the email associated with their booking.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_email": {
                    "type": "string",
                    "description": "Email address associated with the booking"
                }
            },
            "required": ["client_email"]
        }
    },
    {
        "name": "confirm_and_cancel",
        "description": "Call this ONLY after user confirms they want to cancel. Actually cancels the appointment.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_email": {"type": "string"}
            },
            "required": ["client_email"]
        }
    },
]

# =============================================================================
# SEND EMAIL FLOW (3 parameters)
# Sequence: initiate -> recipient -> subject -> message -> confirm
# =============================================================================

EMAIL_FUNCTIONS = [
    {
        "name": "initiate_email",
        "description": "Call this FIRST when user wants to send an email. Asks for recipient.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_email_recipient",
        "description": "Call this AFTER user provides the recipient's email address.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {
                    "type": "string",
                    "description": "Recipient's email address"
                }
            },
            "required": ["to"]
        }
    },
    {
        "name": "collect_email_subject",
        "description": "Call this AFTER user provides the email subject line.",
        "parameters": {
            "type": "object",
            "properties": {
                "subject": {
                    "type": "string",
                    "description": "Email subject line"
                }
            },
            "required": ["subject"]
        }
    },
    {
        "name": "collect_email_message",
        "description": "Call this AFTER user provides the email body/message content.",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "Email body content"
                }
            },
            "required": ["message"]
        }
    },
    {
        "name": "confirm_and_send_email",
        "description": "Call this ONLY after user confirms they want to send the email.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "message": {"type": "string"}
            },
            "required": ["to", "subject", "message"]
        }
    },
]

# =============================================================================
# SEND SMS FLOW (2 parameters)
# Sequence: initiate -> phone -> message -> confirm
# =============================================================================

SMS_FUNCTIONS = [
    {
        "name": "initiate_sms",
        "description": "Call this FIRST when user wants to send an SMS. Asks for phone number.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_sms_phone",
        "description": "Call this AFTER user provides the phone number. Must include country code (e.g., +234 for Nigeria, +1 for US).",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {
                    "type": "string",
                    "description": "Phone number with country code (E.164 format, e.g., +2348012345678)"
                }
            },
            "required": ["to"]
        }
    },
    {
        "name": "collect_sms_message",
        "description": "Call this AFTER user provides the SMS message content.",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "SMS message content"
                }
            },
            "required": ["message"]
        }
    },
    {
        "name": "confirm_and_send_sms",
        "description": "Call this ONLY after user confirms they want to send the SMS.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "message": {"type": "string"}
            },
            "required": ["to", "message"]
        }
    },
]

# =============================================================================
# SEND WHATSAPP FLOW (2 parameters)
# Sequence: initiate -> phone -> message -> confirm
# =============================================================================

WHATSAPP_FUNCTIONS = [
    {
        "name": "initiate_whatsapp",
        "description": "Call this FIRST when user wants to send a WhatsApp message. Asks for phone number.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "collect_whatsapp_phone",
        "description": "Call this AFTER user provides the WhatsApp phone number. Must include country code.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {
                    "type": "string",
                    "description": "Phone number with country code (E.164 format)"
                }
            },
            "required": ["to"]
        }
    },
    {
        "name": "collect_whatsapp_message",
        "description": "Call this AFTER user provides the WhatsApp message content.",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "WhatsApp message content"
                }
            },
            "required": ["message"]
        }
    },
    {
        "name": "confirm_and_send_whatsapp",
        "description": "Call this ONLY after user confirms they want to send the WhatsApp message.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "message": {"type": "string"}
            },
            "required": ["to", "message"]
        }
    },
]

# =============================================================================
# SIMPLE ACTIONS (no sequential collection needed)
# =============================================================================

SIMPLE_FUNCTIONS = [
    {
        "name": "search_web",
        "description": "Search the web for information. Ask user what they want to search for, then call this function.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_current_datetime",
        "description": "Get the current date and time. No parameters needed.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "get_location_info",
        "description": "Get business location and hours information. No parameters needed.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
]

# =============================================================================
# COMBINED FUNCTION DEFINITIONS
# Export this for use in agent_config.py
# =============================================================================

FUNCTION_DEFINITIONS = (
    BOOKING_FUNCTIONS +
    RESCHEDULE_FUNCTIONS +
    CANCEL_FUNCTIONS +
    EMAIL_FUNCTIONS +
    SMS_FUNCTIONS +
    WHATSAPP_FUNCTIONS +
    SIMPLE_FUNCTIONS
)

# Function name to flow mapping (for function handler)
FUNCTION_FLOWS = {
    # Booking flow
    "initiate_booking": "booking",
    "collect_client_name": "booking",
    "collect_client_email": "booking",
    "collect_booking_date": "booking",
    "collect_booking_time": "booking",
    "collect_service_type": "booking",
    "collect_purpose": "booking",
    "confirm_and_book": "booking",

    # Reschedule flow
    "initiate_reschedule": "reschedule",
    "collect_reschedule_booking_id": "reschedule",
    "collect_new_date": "reschedule",
    "collect_new_time": "reschedule",
    "confirm_and_reschedule": "reschedule",

    # Cancel flow
    "initiate_cancel": "cancel",
    "collect_cancel_booking_id": "cancel",
    "collect_cancel_email": "cancel",
    "confirm_and_cancel": "cancel",

    # Email flow
    "initiate_email": "email",
    "collect_email_recipient": "email",
    "collect_email_subject": "email",
    "collect_email_message": "email",
    "confirm_and_send_email": "email",

    # SMS flow
    "initiate_sms": "sms",
    "collect_sms_phone": "sms",
    "collect_sms_message": "sms",
    "confirm_and_send_sms": "sms",

    # WhatsApp flow
    "initiate_whatsapp": "whatsapp",
    "collect_whatsapp_phone": "whatsapp",
    "collect_whatsapp_message": "whatsapp",
    "confirm_and_send_whatsapp": "whatsapp",

    # Simple actions
    "search_web": "simple",
    "get_current_datetime": "simple",
    "get_location_info": "simple",
}
